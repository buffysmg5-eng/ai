import json,subprocess,sys,os
def fetch(url,out):
    for a in range(4):
        subprocess.run(["curl","-sSL","--max-time","60","--retry","3","--retry-delay","2",
                        "--compressed","-o",out,url],capture_output=True)
        try:
            return json.load(open(out))
        except Exception:
            continue
    return None
def item(i):
    d=fetch(f"https://www.loc.gov/item/{i}/?fo=json", f"it_{i}.json")
    print(f"=== {i} ===")
    if d is None: print("  FETCH/PARSE FAIL"); return
    it=d.get("item",{})
    print(" title :",str(it.get('title'))[:80])
    print(" date  :",it.get('date'))
    print(" rights:",str(it.get('rights') or it.get('rights_advisory'))[:200])
    best=None
    for res in d.get("resources",[]):
        for f in res.get("files",[]):
            for v in (f if isinstance(f,list) else [f]):
                if v.get("mimetype")=="image/jpeg":
                    if best is None or (v.get("width") or 0)>(best.get("width") or 0): best=v
    if best: print(f" image : {best.get('url')} ({best.get('width')}x{best.get('height')})")
for i in sys.argv[1:]: item(i)
