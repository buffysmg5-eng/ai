import json,subprocess,sys,urllib.parse
def search(q, n=8, coll="photos"):
    url=f"https://www.loc.gov/{coll}/?q={urllib.parse.quote(q)}&fo=json&c={n}"
    r=subprocess.run(["curl","-sSL","--max-time","40",url],capture_output=True)
    try: d=json.loads(r.stdout)
    except Exception as e: print("  PARSE FAIL",e); return
    for x in d.get("results",[])[:n]:
        rights=str(x.get("rights") or "")[:70]
        img=(x.get("image_url") or [None])[-1]
        print(f"  · {str(x.get('title'))[:64]}")
        print(f"    date={x.get('date')}  id={x.get('id')}")
        print(f"    rights={rights}")
for q in sys.argv[1:]:
    print(f"=== {q} ===")
    search(q)
