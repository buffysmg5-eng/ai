# -*- coding: utf-8 -*-
# [시장 브리핑 28] 미국 30년물 5.3%, 베센트 vs 워시
import json, html, os, shutil
EM_COLOR="#F03030"; EM_FONT="나눔스퀘어"; ST_COLOR="#1F4E79"
CSS_FONT="'나눔스퀘어', NanumSquare, sans-serif"
HL_Y="linear-gradient(transparent 55%, #fff3a0 55%)"; HL_G="linear-gradient(transparent 55%, #d8f5b8 55%)"
def P(*runs):
    out=[]
    for r in runs: out.append({"text":r} if isinstance(r,str) else r)
    return {"type":"paragraph","runs":out}
def SRC(t): return {"type":"paragraph","runs":[{"text":t,"fontSize":15}]}
def B(t):  return {"text":t,"bold":True}
def EM(t): return {"text":t,"bold":True,"color":EM_COLOR,"font":EM_FONT}
def HL(t): return {"text":t,"bold":True,"bgColor":"yellow"}
def HG(t): return {"text":t,"bold":True,"bgColor":"green"}
BL={"type":"blank"}; DV={"type":"divider"}
def ST(t): return {"type":"sectionTitle","text":t,"color":ST_COLOR}
def Q(t,style="quotation_line"): return {"type":"quote","style":style,"text":t}
def IMG(f,c): return {"type":"image","file":f,"caption":c}
LOCH="소장: 미국 의회도서관 하이스미스 아카이브 · 퍼블릭 도메인"
LOCE="소장: 미국 의회도서관 해리스&유잉 컬렉션 · 공개 제한 없음"

blocks=[
 Q("지킬 수 없는 수준은 절대 입 밖에 내지 않는다 — 파운드를 무너뜨려 본 사람이 재무장관이 되면 생기는 습관"),
 BL,
 P("미국 30년물 국채금리가 8월 17일 ",EM("5.31%"),"를 찍었습니다. 2007년 이후 최고입니다. 9월 9일 현재 5.28%로, 고점 근처에서 내려오지 않고 있습니다."),
 BL,
 P("27편에서 중국과 일본을 봤으니 오늘은 미국입니다. 재무부가 장기금리를 누르려고 무엇을 했고, 연준은 왜 안 도와주는지, 시장은 어느 쪽에 돈을 걸어 놓았는지, 그리고 ",B("40조 달러 부채"),"는 결국 어떻게 되는지를 원자료로 봅니다. 4부작 두 번째입니다."),
 DV,

 ST("① 30년물 5.3% — 무슨 일이 있었나"),
 IMG("images/01-dgs30.png","미국 30년물 국채금리 2026년 (자료: 세인트루이스 연준 FRED, 재무부 고시)"),
 BL,
 P("연초 4.86%였던 30년물은 2월 말 4.64%까지 내려갔다가 5월에 5%를 넘었고, 7월 말부터 5.2%대에 자리를 잡았습니다. 8월 17일 5.31%가 고점입니다. 배경은 셋입니다. 개인소비지출 물가(PCE)가 3.7%로 목표를 5년째 웃돌고, 재정적자가 GDP의 6%대인데, 그 적자를 메울 국채를 사 줄 큰손이 줄고 있습니다. 연준은 사지 않고, 일본은 자기 금리가 올라 집으로 돌아가고 있습니다."),
 BL,
 P("그래서 ",HL("장기금리는 정부가 돈을 빌리는 값"),"이면서 동시에 주택담보대출과 회사채, 주식 할인율의 기준값입니다. 30년물이 5%를 넘으면 그 아래 모든 자산의 값이 다시 매겨집니다."),
 DV,

 ST("② 재무부의 첫 수 — 바이백 두 배, 그리고 되돌림"),
 IMG("images/07-hamilton.jpg","미국 재무부 청사와 초대 재무장관 알렉산더 해밀턴 동상, 1980~2006년 촬영. "+LOCH),
 P("8월 19일 베센트 재무장관이 움직였습니다. 10년 초과 국채를 시장에서 되사 주는 '유동성 지원 바이백(liquidity support buyback)'을 회당 20억 달러에서 ",B("40억 달러 이상"),"으로 늘렸고, 9월 9일부터 11월 4일 리펀딩까지 이어갑니다. 연간으로 660억 달러, 20~30년물 총공급의 15%쯤 되는 규모입니다. 이 돈은 단기 국채(T-bill)를 더 팔아서 마련합니다."),
 BL,
 IMG("images/02-spread.png","30년물과 2년물의 금리 차 (자료: FRED DGS30·DGS2)"),
 BL,
 P("발표 당일 30년물은 5.28%에서 5.19%로 내렸고, 30년-2년 차이는 112bp에서 100bp로 좁혀졌습니다. 그런데 이틀 뒤 5.27%로 돌아왔습니다. 시장이 ",B("\"40억으로는 안 된다\""),"고 답한 셈입니다. 미국 국채 하루 거래대금이 1조 달러이니 바이백 한 번은 그 0.4%입니다."),
 BL,
 P("그 뒤 커브가 더 평평해졌는데, 이건 재무부의 공이 아닙니다. 8월 28일 잭슨홀 연설 뒤 ",HL("2년물이 4.20%에서 4.34%로 뛰었습니다"),". 장기물이 내려서가 아니라 단기물이 올라서 좁혀진 겁니다. 이 차이가 다음 절의 핵심입니다."),
 DV,

 ST("③ 워시의 연준 — 거울의 방에서 나오겠다"),
 IMG("images/08-fed-dedication.jpg","연준 신청사 헌정식에서 연설하는 루스벨트 대통령, 1937년 10월 20일. "+LOCE),
 P("같은 주에 워시 의장이 잭슨홀에서 취임 100일 연설을 했습니다. 요지는 두 가지입니다. 물가가 3.7%로 아직 높으니 ",B("할 일이 남았다"),"는 것, 그리고 연준이 앞으로의 금리 경로를 미리 말해 주는 관행(forward guidance)을 줄이겠다는 것입니다. 시장이 연준을 보고 연준이 시장을 보는 구조를 그는 거울의 방이라고 불렀습니다."),
 BL,
 P("장기금리와 관련해 더 중요한 대목은 따로 있습니다. 비전통적 정책, 즉 국채 매입 같은 대차대조표 정책은 ",HG("진짜 위기 때만, 그마저도 아껴서"),"라고 했습니다. 재무부가 장기물을 사는 그 주에 연준은 안 사겠다고 못 박은 겁니다. 게다가 워시는 연준 보유 국채의 만기를 오히려 짧게 가져가는 쪽을 선호해 왔습니다. 재무부는 장기물을 줄이고, 연준은 장기물을 덜 사겠다는 것이니 두 기관이 반대 방향으로 걷고 있습니다."),
 BL,
 P("1951년에도 비슷한 일이 있었습니다. 전쟁 중 연준은 장기국채 2.5% 상한을 지켜 줬고 전쟁이 끝난 뒤에도 재무부는 그걸 원했습니다. 물가가 두 자릿수로 튀자 연준이 거부했고, 1951년 3월 협약으로 금리 페그가 끝났습니다. 지금은 방향만 거꾸로일 뿐 구도가 같습니다. 그때는 연준이 이겼습니다."),
 IMG("images/09-eccles.jpg","연준 의장 매리너 에클스, 1937년 1월. 전후 금리 페그 해제를 주장하며 재무부와 맞섰다. "+LOCE),
 DV,

 ST("④ 재무부의 진짜 탄약 — 현금 8,833억 달러"),
 IMG("images/04-tga.png","재무부 일반계정(TGA) 잔액 (자료: FRED, 연준 H.4.1)"),
 BL,
 P("바이백이 상징이라면 실탄은 따로 있습니다. 재무부가 뉴욕 연준에 둔 주거래 계좌, ",B("재무부 일반계정(Treasury General Account, TGA)"),"입니다. 세금과 국채 판 돈이 여기로 들어오고 연금·급여·국채 이자가 여기서 나갑니다. 9월 9일 주간 평균 잔액이 8,833억 달러로, 코로나 직후를 빼면 역사상 가장 두꺼운 구간입니다."),
 BL,
 P("9월 15일은 법인과 개인의 예정납부일입니다. 재무부는 8월 리펀딩 문서에서 이 세수를 감안해 9월 말 잔액을 9,500억, 10월 말 최고점을 1조 500억 달러로 잡아 놓았습니다. 세금이 TGA로 들어가는 날은 그 돈이 은행 지급준비금에서 빠져나가는 날이라, 매년 이맘때 단기자금시장이 가장 마릅니다. 2019년 9월 레포 금리가 하루 만에 10%까지 튄 게 바로 이 날짜였습니다."),
 BL,
 P("카드는 이겁니다. 쌓인 현금을 헐어 지출하면서 ",HL("장기물 입찰 규모를 줄이는 것"),". 11월 4일 리펀딩이 그 결정 지점입니다. 8월 문서에는 장기물 규모를 '최소 몇 분기 유지'라고 되어 있어 아직 꺼내지 않은 카드입니다. 2023년 10월 10년물이 5%를 찍었을 때 옐런 재무부가 장기물 발행을 줄여 금리를 꺾은 선례가 있고, 그때 베센트는 그것을 재무부의 사실상 QE라고 비판했습니다. 지금은 본인이 더 큰 버전을 준비하는 위치에 있습니다."),
 DV,

 ST("⑤ 시장은 어느 쪽에 서 있나 — 빠른 돈은 숏, 진짜 돈은 롱"),
 IMG("images/03-cftc.png","레버리지펀드의 국채선물 숏÷롱 비율, 계약별 (자료: CFTC, 9월 1일 기준)"),
 BL,
 P("미국 상품선물거래위원회(CFTC)가 매주 공개하는 포지션을 보면 헤지펀드는 전 구간에서 국채선물 순숏, 연기금·보험 같은 자산운용사는 전 구간 순롱입니다. 다만 이 숫자를 곧바로 방향 베팅으로 읽으면 안 됩니다. 헤지펀드 선물 숏의 상당 부분은 현물을 사고 선물을 파는 ",B("베이시스 거래(basis trade)"),"라서 금리 방향과 무관합니다. 연준 6월 노트에 따르면 그 규모가 8,300억 달러, 2020년 정점의 두 배입니다."),
 BL,
 P("방향성을 걸러내는 방법은 구간별 편중입니다. 베이시스 거래라면 숏÷롱 비율이 구간마다 비슷해야 합니다. 그런데 2년물 3.1배, 10년물 6.5배인데 ",EM("울트라 30년물만 13배"),"입니다. 30년 초장기 구간에만 차익거래로 설명이 안 되는 숏이 얹혀 있습니다. 같은 노트에서 헤지펀드의 곡선 거래는 스티프너(단기 롱·장기 숏) 3,750억 대 플래트너 1,750억으로 2대 1입니다."),
 BL,
 P("정리하면 빠른 돈은 ",HL("초장기 숏과 스티프너에 몰려 있고"),", 진짜 돈은 장기물을 계속 사고 있습니다. 8월 19일 바이백 발표 당일 하루 만에 커브가 12bp 평평해진 건 그 스티프너가 손절하며 되감긴 크기이고, 며칠 만에 되돌아간 건 되감기가 끝나자 같은 자리를 다시 잡았다는 뜻입니다."),
 DV,

 ST("⑥ 베센트라는 사람 — 소로스의 두 거래"),
 P("베센트는 소로스 펀드에서 두 번 일했습니다. 1990년대 런던에서 1992년 파운드 공격의 실무를 맡았고, 2011~2015년 최고투자책임자로 돌아와 2013년 아베노믹스 엔 약세에 크게 걸었습니다. 두 거래의 공통점은 ",B("당국이 지키겠다고 한 약속 중 지킬 수 없는 것을 찾아 반대편에 서는 것"),"이었습니다. 영란은행은 외환보유고가 유한했고, 일본은행은 엔 약세를 원했습니다."),
 BL,
 P("그래서 그가 지금 절대 안 하는 일이 하나 있습니다. 목표 금리를 말하는 것입니다. 30년물 5%를 막겠다고 하는 순간 본인이 1992년의 영란은행이 됩니다. 바이백을 '유동성 지원'이라 부르고 수준을 절대 언급하지 않는 건 그 학습의 결과로 읽힙니다."),
 BL,
 IMG("images/05-cards.png","재무부의 카드 다섯 장, 실행·예고·보류 (작도: 직접 제작)"),
 BL,
 P("이미 쓴 카드가 둘입니다. 바이백, 그리고 27편에서 본 7월 31일 미·일 공동 엔 개입입니다. 개입은 달러가 아니라 ",B("유로를 팔아 엔을 샀고"),", 유럽중앙은행에는 사전 통보도 하지 않았습니다. 달러 매도라는 딱지를 피하면서 엔을 올린 겁니다. 1992년엔 시장이 틀린 자리를 찾아 공격했다면, 지금은 시장이 틀린 자리(164엔)를 찾아 방어한 것이니 같은 원칙의 뒤집힌 버전입니다."),
 BL,
 P("남은 카드는 셋입니다. TGA를 헐어 장기물 발행을 줄이는 것, 은행 자본규제(보완적 레버리지 비율, SLR)에서 국채를 빼 은행이 국채를 담게 하는 것, 그리고 연준 장부에 온스당 42달러로 잡힌 금 증서 2억 6천만 온스를 시가로 다시 매기는 것입니다. 셋 다 국채를 한 장도 더 찍지 않고 수요나 재원을 만드는 방법이고, 그래서 초장기 숏을 한 번에 쥐어짤 수 있는 카드입니다."),
 DV,

 ST("⑦ 그래서 부채는 — 네 가지 길"),
 P("연방정부 총부채는 2026년 1분기 ",B("39조 700억 달러"),"입니다. 2008년 9조 4천억에서 2020년 초 23조, 코로나 한 해에 4조 5천억이 붙었고 그 뒤 매년 2조씩 늘었습니다. 의회예산국(CBO)은 순이자를 올해 1조 달러(GDP의 3.3%)에서 2036년 2조 1천억(4.6%)으로 봅니다. 이자가 이미 국방비보다 큽니다."),
 BL,
 P("역사적으로 이런 부채를 줄인 길은 넷뿐입니다. 성장률이 이자율을 넘기는 것, 인플레이션과 금융억압으로 실질가치를 녹이는 것, 증세와 지출삭감, 그리고 디폴트입니다. 미국은 자국 통화로 빚을 진 나라라 넷째는 선택이지 강제가 아니고, 셋째는 정치적으로 가장 어렵습니다. 그래서 첫째를 기대하면서 ",HL("둘째를 조용히 진행하는 조합"),"이 될 가능성이 큽니다. 1946년 106%였던 부채비율이 1970년대 초 25%까지 내려간 게 그 길이었습니다."),
 BL,
 P("바이백, 단기물 전환, 스테이블코인과 은행 규제로 국채 수요를 만들어 주는 지금의 정책은 둘째 길의 초입으로 읽힙니다. 다만 그때는 자본통제와 금리상한이 있었고 지금은 없습니다. 시장이 협조를 거부하면, 즉 장기금리가 오르면 바로 들통납니다. 8월의 30년물 5.31%는 시장이 그걸 눈치챘다는 신호였습니다."),
 DV,

 ST("⑧ 관전표 — 앞으로 8주"),
 IMG("images/06-calendar.png","장기금리를 가를 다섯 날 (작도: 직접 제작)"),
 BL,
 P("이 글은 채점판 대신 관전표를 답니다. 재무부 쪽은 탄약과 카드가 더 많고, 연준과 일본은행 쪽은 시간이 더 유리합니다. 9월 16일 연준이 올리고 17~18일 일본은행이 올리면 그 주에는 재무부의 어떤 카드도 힘을 못 씁니다. 반대로 11월 4일 리펀딩에서 장기물 입찰 축소가 나오면 초장기 숏이 먼저 흔들립니다. ",HG("11월 4일이 이 글의 채점일"),"입니다."),
 BL,
 P("다음 편은 한국입니다. 미국 장기금리와 일본 금리가 동시에 오를 때 원화, 국고채, 외국인 자금이 어떻게 움직였는지, 11월 WGBI 편입을 앞두고 무엇을 봐야 하는지 봅니다."),
 DV,

 SRC("자료: 세인트루이스 연준 FRED(DGS30·DGS2·WTREGEN·GFDEBTN), 미국 재무부 2026년 8월 리펀딩 성명 및 9월 9일 바이백 확대 발표, 연준 H.4.1(2026.9.10), 연준 이사회 워시 의장 잭슨홀 연설(2026.8.28), 연준 FEDS Notes '헤지펀드 국채 익스포저 분해'(2026.6.22), CFTC Traders in Financial Futures(2026.9.1), 의회예산국 2026년 장기 재정전망, 상원 은행위원회 서한(2026.8.13)."),
 SRC("사진: 미국 의회도서관 인쇄·사진부 — 하이스미스 아카이브(재무부 청사), 해리스&유잉 컬렉션(1937년 연준 신청사 헌정식·에클스 의장). 모두 공개 제한 없음으로 표시된 자료."),
 SRC("이 글은 투자 권유가 아니며 특정 종목이나 상품의 매수·매도를 추천하지 않습니다. 정책 의도에 관한 서술은 공개 발언과 발표 원문에서 추론한 것이며 확인된 계획이 아닙니다."),
]

def runs_of(b): return b.get("runs",[]) if b.get("type")=="paragraph" else []
text="".join(r["text"] for b in blocks for r in runs_of(b))+"".join(b.get("text","") for b in blocks if b.get("type") in ("sectionTitle","quote"))
chars=len(text); bolds=[r for b in blocks for r in runs_of(b) if r.get("bold")]
ratio=sum(len(r["text"]) for r in bolds)/max(chars,1)
quotes=[b for b in blocks if b.get("type")=="quote"]; hls=[r for b in blocks for r in runs_of(b) if r.get("bgColor")]
ems=[r for b in blocks for r in runs_of(b) if r.get("color")]; imgs=[b for b in blocks if b.get("type")=="image"]
for b in blocks: assert len([r for r in runs_of(b) if r.get("color")])<=1
assert 2500<=chars<=7000, f"글자수 {chars}"; assert len(bolds)>=8; assert ratio<=0.10, f"굵기비중 {ratio:.3f}"
assert len(quotes)>=1; assert 3<=len(hls)<=8, f"형광펜 {len(hls)}"
for r in hls:
    n=len(r["text"]); assert 6<=n<=45, f"형광펜 길이 {n}: {r['text']}"; assert '(' not in r["text"] and ')' not in r["text"]
print(f"글자수 {chars} / 굵게 {len(bolds)} ({ratio*100:.1f}%) / 색 {len(ems)} / 형광펜 {len(hls)} / 인용구 {len(quotes)} / 이미지 {len(imgs)}")

SRCDIR="/home/user/market-blog/re49"
for d in ("pkg48","pkg48t"):
    p=f"/home/user/market-blog/{d}/images"; shutil.rmtree(f"/home/user/market-blog/{d}",ignore_errors=True); os.makedirs(p)
    for b in imgs: f=os.path.basename(b["file"]); shutil.copy(f"{SRCDIR}/{f}", f"{p}/{f}")
TITLE="미국 30년물 국채금리 5.3%, 베센트의 바이백과 워시의 연준 — 장기금리는 누가 이기나, 40조 달러 부채는 어디로 가나 [시장 브리핑 28]"
TAGS=["미국국채금리","30년물","베센트","연준","미국부채"]
META={"title":TITLE,"category":"시장 브리핑","tags":TAGS,"series":{"name":"시장 브리핑","no":28},"charCount":chars}
json.dump({"meta":META,"blocks":blocks},open("/home/user/market-blog/pkg48/content.json","w"),ensure_ascii=False,indent=1)
json.dump({"title":TITLE,"category":"시장 브리핑","tags":TAGS,"publishMode":"draft","coupang":False},open("/home/user/market-blog/pkg48t/meta.json","w"),ensure_ascii=False,indent=1)
def esc(t): return html.escape(t)
out=[f"<h1>{esc(TITLE)}</h1>"]
for b in blocks:
    t=b["type"]
    if t=="paragraph":
        s=""
        for r in b["runs"]:
            x=esc(r["text"]); st=[]
            if r.get("bold"): st.append("font-weight:700")
            if r.get("color"): st.append(f"color:{r['color']};font-family:{CSS_FONT}")
            if r.get("bgColor")=="yellow": st.append(f"background:{HL_Y}")
            if r.get("bgColor")=="green": st.append(f"background:{HL_G}")
            if r.get("fontSize"): st.append(f"font-size:{r['fontSize']}px;color:#888")
            s+=f"<span style=\"{';'.join(st)}\">{x}</span>" if st else x
        out.append(f"<p>{s}</p>")
    elif t=="sectionTitle": out.append(f"<h2 style=\"color:{ST_COLOR}\">{esc(b['text'])}</h2>")
    elif t=="quote": out.append(f"<blockquote>{esc(b['text'])}</blockquote>")
    elif t=="image": out.append(f"<figure><img src=\"{b['file']}\" style=\"max-width:100%\"><figcaption>{esc(b['caption'])}</figcaption></figure>")
    elif t=="divider": out.append("<hr>")
    elif t=="blank": out.append("<p>&nbsp;</p>")
open("/home/user/market-blog/pkg48t/content.html","w").write("<meta charset='utf-8'><body style=\"max-width:760px;margin:0 auto;font-family:sans-serif;line-height:1.9\">"+"\n".join(out)+"</body>")
print("packaged: pkg48 / pkg48t")
